namespace GestionProyectos.Web.Services;

public static class ClaimsSesion
{
    public const string Token = "access_token";
}
