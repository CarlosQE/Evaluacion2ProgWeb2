using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using GestionProyectos.Contratos.Comun;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;

namespace GestionProyectos.Web.Services;

public class ApiCliente(HttpClient http, AuthenticationStateProvider autenticacion, NavigationManager nav)
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() },
    };

    public async Task<T?> ObtenerAsync<T>(string url)
    {
        using var respuesta = await EnviarAsync(HttpMethod.Get, url, null, conToken: true);
        if (respuesta.StatusCode == HttpStatusCode.NotFound) return default;
        if (!respuesta.IsSuccessStatusCode) throw new ApiException((await LeerErrorAsync(respuesta)).Mensaje);
        return await respuesta.Content.ReadFromJsonAsync<T>(Json);
    }

    public async Task<Resultado<T>> EnviarAsync<T>(HttpMethod metodo, string url, object cuerpo, bool conToken = true)
    {
        using var respuesta = await EnviarAsync(metodo, url, cuerpo, conToken);
        if (respuesta.IsSuccessStatusCode)
            return Resultado<T>.Ok((await respuesta.Content.ReadFromJsonAsync<T>(Json))!);

        var (tipo, mensaje) = await LeerErrorAsync(respuesta);
        return new Resultado<T>(default, tipo, mensaje);
    }

    private async Task<HttpResponseMessage> EnviarAsync(HttpMethod metodo, string url, object? cuerpo, bool conToken)
    {
        using var peticion = new HttpRequestMessage(metodo, url);
        if (cuerpo is not null) peticion.Content = JsonContent.Create(cuerpo, cuerpo.GetType(), options: Json);

        if (conToken)
        {
            var usuario = (await autenticacion.GetAuthenticationStateAsync()).User;
            var token = usuario.FindFirst(ClaimsSesion.Token)?.Value;
            if (token is not null) peticion.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        HttpResponseMessage respuesta;
        try
        {
            respuesta = await http.SendAsync(peticion);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            throw new ApiException(
                $"No se pudo conectar con la API ({http.BaseAddress}). Verifique que el proyecto GestionProyectos.Api esté en ejecución.", ex);
        }

        if (conToken && respuesta.StatusCode == HttpStatusCode.Unauthorized)
        {
            nav.NavigateTo("salir?expirado=1", forceLoad: true);
            throw new ApiException("Su sesión expiró. Inicie sesión de nuevo.");
        }

        return respuesta;
    }

    private static async Task<(TipoError Tipo, string Mensaje)> LeerErrorAsync(HttpResponseMessage respuesta)
    {
        var tipo = respuesta.StatusCode switch
        {
            HttpStatusCode.NotFound => TipoError.NoEncontrado,
            HttpStatusCode.Conflict => TipoError.Conflicto,
            HttpStatusCode.Unauthorized => TipoError.NoAutorizado,
            _ => TipoError.Validacion,
        };

        string? mensaje = null;
        try
        {
            var problema = await respuesta.Content.ReadFromJsonAsync<Problema>(Json);
            mensaje = problema?.Errors is { Count: > 0 } errores
                ? string.Join(" ", errores.Values.SelectMany(v => v))
                : problema?.Detail ?? problema?.Title;
        }
        catch (JsonException) { }
        catch (NotSupportedException) { }

        return (tipo, mensaje ?? $"La API respondió con el código {(int)respuesta.StatusCode}.");
    }

    private sealed record Problema(string? Title, string? Detail, Dictionary<string, string[]>? Errors);
}

public class ApiException(string mensaje, Exception? interna = null) : Exception(mensaje, interna);
