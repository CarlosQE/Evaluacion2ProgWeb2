using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;

namespace GestionProyectos.Web.Services;

public class ProyectoApiService(ApiCliente api) : IProyectoService
{
    public async Task<List<ProyectoRespuestaDto>> ListarAsync(string? texto, EstadoProyecto? estado)
    {
        var filtros = new List<string>();
        if (!string.IsNullOrWhiteSpace(texto)) filtros.Add($"texto={Uri.EscapeDataString(texto)}");
        if (estado is not null) filtros.Add($"estado={estado}");
        var url = filtros.Count == 0 ? "api/proyectos" : $"api/proyectos?{string.Join('&', filtros)}";
        return await api.ObtenerAsync<List<ProyectoRespuestaDto>>(url) ?? [];
    }

    public Task<ProyectoRespuestaDto?> ObtenerAsync(int id) => api.ObtenerAsync<ProyectoRespuestaDto>($"api/proyectos/{id}");

    public Task<Resultado<ProyectoRespuestaDto>> CrearAsync(ProyectoCrearDto dto) =>
        api.EnviarAsync<ProyectoRespuestaDto>(HttpMethod.Post, "api/proyectos", dto);

    public Task<Resultado<ProyectoRespuestaDto>> CambiarEstadoAsync(int id, EstadoProyecto estado) =>
        api.EnviarAsync<ProyectoRespuestaDto>(HttpMethod.Patch, $"api/proyectos/{id}/estado", new ProyectoCambiarEstadoDto(estado));
}
