using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;

namespace GestionProyectos.Web.Services;

public class JefeApiService(ApiCliente api) : IJefeService
{
    public async Task<List<JefeRespuestaDto>> ListarAsync(string? texto) =>
        await api.ObtenerAsync<List<JefeRespuestaDto>>(
            string.IsNullOrWhiteSpace(texto) ? "api/jefes" : $"api/jefes?texto={Uri.EscapeDataString(texto)}") ?? [];

    public Task<JefeRespuestaDto?> ObtenerAsync(int id) => api.ObtenerAsync<JefeRespuestaDto>($"api/jefes/{id}");

    public Task<Resultado<JefeRespuestaDto>> CrearAsync(JefeCrearDto dto) =>
        api.EnviarAsync<JefeRespuestaDto>(HttpMethod.Post, "api/jefes", dto);
}
