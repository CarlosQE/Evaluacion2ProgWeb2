using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;

namespace GestionProyectos.Web.Services;

public class AuthApiService(ApiCliente api) : IAuthService
{
    public Task<Resultado<TokenDto>> IniciarSesionAsync(LoginDto login) =>
        api.EnviarAsync<TokenDto>(HttpMethod.Post, "api/auth/login", login, conToken: false);
}
