using System.ComponentModel.DataAnnotations;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Validaciones;

namespace GestionProyectos.Web.Modelos;

public class LoginFormulario
{
    [Required(ErrorMessage = "Ingrese su usuario.")]
    [StringLength(40, ErrorMessage = "El usuario no puede superar {1} caracteres.")]
    public string NombreUsuario { get; set; } = string.Empty;

    [Required(ErrorMessage = "Ingrese su contraseña.")]
    [StringLength(100, ErrorMessage = "La contraseña no puede superar {1} caracteres.")]
    public string Contrasena { get; set; } = string.Empty;

    public bool Recordarme { get; set; }

    public LoginDto ADto() => new(NombreUsuario.Trim(), Contrasena);
}

public class JefeFormulario
{
    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [StringLength(100, ErrorMessage = "El nombre no puede superar {1} caracteres.")]
    [NombrePersona]
    public string Nombre { get; set; } = string.Empty;

    [Required(ErrorMessage = "El cargo es obligatorio.")]
    [StringLength(80, ErrorMessage = "El cargo no puede superar {1} caracteres.")]
    [Cargo]
    public string Cargo { get; set; } = string.Empty;

    [Required(ErrorMessage = "El correo es obligatorio.")]
    [StringLength(120, ErrorMessage = "El correo no puede superar {1} caracteres.")]
    [Correo]
    public string Correo { get; set; } = string.Empty;

    public JefeCrearDto ADto() => new(Nombre, Cargo, Correo);
}

public class ProyectoFormulario
{
    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [StringLength(120, ErrorMessage = "El nombre no puede superar {1} caracteres.")]
    [NombreProyecto]
    public string Nombre { get; set; } = string.Empty;

    [Required(ErrorMessage = "La descripción es obligatoria.")]
    [StringLength(500, ErrorMessage = "La descripción no puede superar {1} caracteres.")]
    [TextoConContenido(10)]
    public string Descripcion { get; set; } = string.Empty;

    [Range(1, int.MaxValue, ErrorMessage = "Seleccione el jefe a cargo.")]
    public int JefeId { get; set; }

    public EstadoProyecto Estado { get; set; } = EstadoProyecto.Planificado;

    public ProyectoCrearDto ADto() => new(Nombre, Descripcion, JefeId, Estado);
}
