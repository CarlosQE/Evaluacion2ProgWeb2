using GestionProyectos.Contratos.DTOs;

namespace GestionProyectos.Web.Modelos;

public static class EstadoUi
{
    public static string Nombre(EstadoProyecto estado) => estado switch
    {
        EstadoProyecto.Planificado => "Planificado",
        EstadoProyecto.EnProgreso => "En progreso",
        EstadoProyecto.Pausado => "Pausado",
        EstadoProyecto.Finalizado => "Finalizado",
        EstadoProyecto.Cancelado => "Cancelado",
        _ => estado.ToString(),
    };

    public static string Icono(EstadoProyecto estado) => estado switch
    {
        EstadoProyecto.Planificado => "event_note",
        EstadoProyecto.EnProgreso => "play_circle",
        EstadoProyecto.Pausado => "pause_circle",
        EstadoProyecto.Finalizado => "task_alt",
        EstadoProyecto.Cancelado => "cancel",
        _ => "help",
    };

    public static string Css(EstadoProyecto estado) => "estado estado--" + estado.ToString().ToLowerInvariant();

    public static string Accion(EstadoProyecto actual, EstadoProyecto destino) => destino switch
    {
        EstadoProyecto.EnProgreso when actual == EstadoProyecto.Pausado => "Reanudar",
        EstadoProyecto.EnProgreso => "Iniciar",
        EstadoProyecto.Pausado => "Pausar",
        EstadoProyecto.Finalizado => "Finalizar",
        EstadoProyecto.Cancelado => "Cancelar proyecto",
        EstadoProyecto.Planificado => "Reabrir",
        _ => Nombre(destino),
    };
}
