using System.Globalization;
using GestionProyectos.Contratos.Interfaces;
using GestionProyectos.Web.Components;
using GestionProyectos.Web.Services;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

var cultura = CultureInfo.GetCultureInfo("es-BO");
CultureInfo.DefaultThreadCurrentCulture = cultura;
CultureInfo.DefaultThreadCurrentUICulture = cultura;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.LogoutPath = "/logout";
        options.AccessDeniedPath = "/login";
        options.Cookie.Name = "GestionProyectos.Sesion";
        options.Cookie.HttpOnly = true;
        options.SlidingExpiration = false;
    });
builder.Services.AddAuthorization();
builder.Services.AddCascadingAuthenticationState();

var urlApi = builder.Configuration["Api:UrlBase"]
    ?? throw new InvalidOperationException("Falta 'Api:UrlBase' en appsettings.");
builder.Services.AddHttpClient<ApiCliente>(c =>
{
    c.BaseAddress = new Uri(urlApi);
    c.Timeout = TimeSpan.FromSeconds(15);
});

builder.Services.AddScoped<IAuthService, AuthApiService>();
builder.Services.AddScoped<IJefeService, JefeApiService>();
builder.Services.AddScoped<IProyectoService, ProyectoApiService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.MapPost("/logout", async (HttpContext http) =>
{
    await http.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Redirect("/login?salio=1");
}).WithMetadata(new RequireAntiforgeryTokenAttribute());

app.MapGet("/salir", async (HttpContext http) =>
{
    await http.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Redirect("/login?expirado=1");
});

app.Run();
