using System.Globalization;
using System.Text.RegularExpressions;

namespace GestionProyectos.Contratos.Validaciones;

public static partial class Normalizador
{
    private static readonly CultureInfo Cultura = CultureInfo.GetCultureInfo("es");

    private static readonly HashSet<string> Conectores =
        new(["de", "del", "la", "las", "los", "y", "e"], StringComparer.OrdinalIgnoreCase);

    [GeneratedRegex(@"\s+")]
    private static partial Regex EspaciosRegex();

    [GeneratedRegex(@"[ \t]+")]
    private static partial Regex EspaciosHorizontalesRegex();

    [GeneratedRegex(@"\n{3,}")]
    private static partial Regex SaltosRegex();

    public static string Espacios(string? valor) =>
        string.IsNullOrWhiteSpace(valor) ? string.Empty : EspaciosRegex().Replace(valor.Trim(), " ");

    public static string NombrePropio(string? valor)
    {
        var palabras = Espacios(valor).ToLower(Cultura).Split(' ', StringSplitOptions.RemoveEmptyEntries);
        for (var i = 0; i < palabras.Length; i++)
        {
            if (i > 0 && Conectores.Contains(palabras[i])) continue;
            palabras[i] = Capitalizar(palabras[i]);
        }
        return string.Join(' ', palabras);
    }

    public static string PrimeraMayuscula(string? valor)
    {
        var limpio = Espacios(valor);
        return limpio.Length == 0 ? limpio : char.ToUpper(limpio[0], Cultura) + limpio[1..];
    }

    public static string Parrafo(string? valor)
    {
        if (string.IsNullOrWhiteSpace(valor)) return string.Empty;
        var lineas = valor.Replace("\r\n", "\n").Split('\n').Select(l => EspaciosHorizontalesRegex().Replace(l.Trim(), " "));
        var texto = SaltosRegex().Replace(string.Join('\n', lineas), "\n\n").Trim();
        return texto.Length == 0 ? texto : char.ToUpper(texto[0], Cultura) + texto[1..];
    }

    public static string Correo(string? valor) => Espacios(valor).Replace(" ", "").ToLowerInvariant();

    public static string Clave(string? valor)
    {
        var sinTildes = new string(Espacios(valor).Normalize(System.Text.NormalizationForm.FormD)
            .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
            .ToArray());
        return sinTildes.Normalize(System.Text.NormalizationForm.FormC).ToLowerInvariant();
    }

    private static string Capitalizar(string palabra)
    {
        var letras = palabra.ToCharArray();
        var inicio = true;
        for (var i = 0; i < letras.Length; i++)
        {
            if (inicio && char.IsLetter(letras[i]))
            {
                letras[i] = char.ToUpper(letras[i], Cultura);
                inicio = false;
            }
            else if (letras[i] is '-' or '\'')
            {
                inicio = true;
            }
        }
        return new string(letras);
    }
}
