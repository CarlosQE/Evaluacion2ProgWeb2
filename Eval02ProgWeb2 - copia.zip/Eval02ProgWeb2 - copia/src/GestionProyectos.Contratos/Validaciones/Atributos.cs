using System.ComponentModel.DataAnnotations;

namespace GestionProyectos.Contratos.Validaciones;

public abstract class ValidacionTextoAttribute : ValidationAttribute
{
    protected abstract string Normalizar(string valor);
    protected abstract string? Validar(string normalizado);

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value is not string texto || string.IsNullOrWhiteSpace(texto)) return ValidationResult.Success;

        var error = Validar(Normalizar(texto));
        return error is null
            ? ValidationResult.Success
            : new ValidationResult(ErrorMessage ?? error, validationContext.MemberName is { } m ? [m] : null);
    }
}

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter)]
public sealed class NombrePersonaAttribute : ValidacionTextoAttribute
{
    protected override string Normalizar(string valor) => Normalizador.NombrePropio(valor);

    protected override string? Validar(string n)
    {
        if (!Patrones.NombrePersona().IsMatch(n))
            return "El nombre solo puede contener letras y debe incluir nombre y apellido (ej. \"Leon Larregui\").";
        if (n.Split(' ').Any(p => p.Length < 2 && !p.Equals("y", StringComparison.OrdinalIgnoreCase) && !p.Equals("e", StringComparison.OrdinalIgnoreCase)))
            return "Cada parte del nombre debe tener al menos 2 letras (no se aceptan iniciales sueltas).";
        if (Patrones.Repeticion().IsMatch(n))
            return "El nombre tiene caracteres repetidos que no parecen válidos.";
        return null;
    }
}

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter)]
public sealed class CargoAttribute : ValidacionTextoAttribute
{
    protected override string Normalizar(string valor) => Normalizador.PrimeraMayuscula(valor);

    protected override string? Validar(string n)
    {
        if (!Patrones.Cargo().IsMatch(n))
            return "El cargo solo puede contener letras, espacios y los signos . , ( ) / & -";
        if (Patrones.ContarLetras(n) < 2)
            return "El cargo debe tener al menos 2 letras.";
        if (Patrones.Repeticion().IsMatch(n))
            return "El cargo tiene caracteres repetidos que no parecen válidos.";
        return null;
    }
}

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter)]
public sealed class NombreProyectoAttribute : ValidacionTextoAttribute
{
    protected override string Normalizar(string valor) => Normalizador.PrimeraMayuscula(valor);

    protected override string? Validar(string n)
    {
        if (!Patrones.NombreProyecto().IsMatch(n))
            return "El nombre del proyecto contiene caracteres no permitidos.";
        if (Patrones.ContarLetras(n) < 3)
            return "El nombre del proyecto debe tener al menos 3 letras (no puede ser solo números o símbolos).";
        if (Patrones.Repeticion().IsMatch(n))
            return "El nombre del proyecto tiene caracteres repetidos que no parecen válidos.";
        return null;
    }
}

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter)]
public sealed class CorreoAttribute : ValidacionTextoAttribute
{
    protected override string Normalizar(string valor) => Normalizador.Correo(valor);

    protected override string? Validar(string n) =>
        Patrones.Correo().IsMatch(n) ? null : "El correo no es válido. Use el formato usuario@dominio.com";
}

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter)]
public sealed class TextoConContenidoAttribute(int minimoLetras) : ValidacionTextoAttribute
{
    protected override string Normalizar(string valor) => Normalizador.Parrafo(valor);

    protected override string? Validar(string n)
    {
        if (Patrones.ContarLetras(n) < minimoLetras)
            return $"El texto debe tener al menos {minimoLetras} letras con contenido real.";
        if (Patrones.Repeticion().IsMatch(n.Replace(".", "").Replace("-", "")))
            return "El texto tiene caracteres repetidos que no parecen válidos.";
        return null;
    }
}
