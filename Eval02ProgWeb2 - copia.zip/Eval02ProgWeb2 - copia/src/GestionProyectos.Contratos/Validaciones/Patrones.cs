using System.Text.RegularExpressions;

namespace GestionProyectos.Contratos.Validaciones;

public static partial class Patrones
{
    [GeneratedRegex(@"^\p{L}+(?:['-]\p{L}+)*(?: \p{L}+(?:['-]\p{L}+)*)+$")]
    public static partial Regex NombrePersona();

    [GeneratedRegex(@"^[\p{L} .,()/&-]+$")]
    public static partial Regex Cargo();

    [GeneratedRegex(@"^[\p{L}\d .,:;()/&+#'_-]+$")]
    public static partial Regex NombreProyecto();

    [GeneratedRegex(@"^(?!\.)(?!.*\.\.)[a-z0-9._%+-]+(?<!\.)@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$")]
    public static partial Regex Correo();

    [GeneratedRegex(@"\p{L}")]
    public static partial Regex Letra();

    public static int ContarLetras(string texto) => Letra().Count(texto);

    [GeneratedRegex(@"(.)\1{3,}")]
    public static partial Regex Repeticion();
}
