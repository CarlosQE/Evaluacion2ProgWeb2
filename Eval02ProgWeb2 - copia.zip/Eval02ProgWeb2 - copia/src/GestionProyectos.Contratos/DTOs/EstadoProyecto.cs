namespace GestionProyectos.Contratos.DTOs;

public enum EstadoProyecto
{
    Planificado,
    EnProgreso,
    Pausado,
    Finalizado,
    Cancelado
}

public static class EstadosProyecto
{
    public static readonly EstadoProyecto[] Activos =
        [EstadoProyecto.Planificado, EstadoProyecto.EnProgreso, EstadoProyecto.Pausado];

    public static readonly EstadoProyecto[] Iniciales =
        [EstadoProyecto.Planificado, EstadoProyecto.EnProgreso];

    private static readonly Dictionary<EstadoProyecto, EstadoProyecto[]> Transiciones = new()
    {
        [EstadoProyecto.Planificado] = [EstadoProyecto.EnProgreso, EstadoProyecto.Cancelado],
        [EstadoProyecto.EnProgreso] = [EstadoProyecto.Pausado, EstadoProyecto.Finalizado, EstadoProyecto.Cancelado],
        [EstadoProyecto.Pausado] = [EstadoProyecto.EnProgreso, EstadoProyecto.Cancelado],
        [EstadoProyecto.Cancelado] = [EstadoProyecto.Planificado],
        [EstadoProyecto.Finalizado] = [],
    };

    public static bool EsActivo(this EstadoProyecto estado) => Activos.Contains(estado);

    public static IReadOnlyList<EstadoProyecto> SiguientesEstados(this EstadoProyecto estado) =>
        Transiciones.TryGetValue(estado, out var siguientes) ? siguientes : [];

    public static bool PuedeCambiarA(this EstadoProyecto actual, EstadoProyecto nuevo) =>
        actual.SiguientesEstados().Contains(nuevo);
}
