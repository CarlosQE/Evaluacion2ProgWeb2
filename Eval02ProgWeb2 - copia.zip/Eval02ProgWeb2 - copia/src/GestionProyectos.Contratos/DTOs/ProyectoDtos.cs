using System.ComponentModel.DataAnnotations;
using GestionProyectos.Contratos.Validaciones;

namespace GestionProyectos.Contratos.DTOs;

public record ProyectoCrearDto(
    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [StringLength(120, ErrorMessage = "El nombre no puede superar {1} caracteres.")]
    [NombreProyecto]
    string Nombre,

    [Required(ErrorMessage = "La descripción es obligatoria.")]
    [StringLength(500, ErrorMessage = "La descripción no puede superar {1} caracteres.")]
    [TextoConContenido(10)]
    string Descripcion,

    [Range(1, int.MaxValue, ErrorMessage = "Debe indicar un jefe válido (Id mayor a 0).")]
    int JefeId,

    EstadoProyecto Estado = EstadoProyecto.Planificado);

public record ProyectoCambiarEstadoDto(EstadoProyecto Estado);

public record ProyectoRespuestaDto(
    int Id,
    string Nombre,
    string Descripcion,
    EstadoProyecto Estado,
    JefeResumenDto Jefe)
{
    public IReadOnlyList<EstadoProyecto> SiguientesEstados => Estado.SiguientesEstados();
}

public record ProyectoResumenDto(int Id, string Nombre, EstadoProyecto Estado);
