using System.ComponentModel.DataAnnotations;
using GestionProyectos.Contratos.Validaciones;

namespace GestionProyectos.Contratos.DTOs;

public record JefeCrearDto(
    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [StringLength(100, ErrorMessage = "El nombre no puede superar {1} caracteres.")]
    [NombrePersona]
    string Nombre,

    [Required(ErrorMessage = "El cargo es obligatorio.")]
    [StringLength(80, ErrorMessage = "El cargo no puede superar {1} caracteres.")]
    [Cargo]
    string Cargo,

    [Required(ErrorMessage = "El correo es obligatorio.")]
    [StringLength(120, ErrorMessage = "El correo no puede superar {1} caracteres.")]
    [Correo]
    string Correo);

public record JefeRespuestaDto(
    int Id,
    string Nombre,
    string Cargo,
    string Correo,
    ProyectoResumenDto? ProyectoActivo)
{
    public bool Disponible => ProyectoActivo is null;
}

public record JefeResumenDto(int Id, string Nombre, string Cargo, string Correo);
