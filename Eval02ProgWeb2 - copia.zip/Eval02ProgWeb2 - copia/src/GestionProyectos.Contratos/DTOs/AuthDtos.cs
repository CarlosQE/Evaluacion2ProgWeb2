using System.ComponentModel.DataAnnotations;

namespace GestionProyectos.Contratos.DTOs;

public record LoginDto(
    [Required(ErrorMessage = "Ingrese su usuario.")]
    [StringLength(40, ErrorMessage = "El usuario no puede superar {1} caracteres.")]
    string NombreUsuario,

    [Required(ErrorMessage = "Ingrese su contraseña.")]
    [StringLength(100, ErrorMessage = "La contraseña no puede superar {1} caracteres.")]
    string Contrasena);

public record TokenDto(string Token, DateTime ExpiraEnUtc, UsuarioDto Usuario);

public record UsuarioDto(int Id, string NombreUsuario, string NombreCompleto, string Rol);
