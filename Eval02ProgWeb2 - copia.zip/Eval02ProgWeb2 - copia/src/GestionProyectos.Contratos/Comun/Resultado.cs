namespace GestionProyectos.Contratos.Comun;

public enum TipoError { NoEncontrado, Conflicto, Validacion, NoAutorizado }

public record Resultado<T>(T? Valor, TipoError? Error = null, string? Mensaje = null)
{
    public bool Exito => Error is null;

    public static Resultado<T> Ok(T valor) => new(valor);
    public static Resultado<T> NoEncontrado(string mensaje) => new(default, TipoError.NoEncontrado, mensaje);
    public static Resultado<T> Conflicto(string mensaje) => new(default, TipoError.Conflicto, mensaje);
    public static Resultado<T> Validacion(string mensaje) => new(default, TipoError.Validacion, mensaje);
    public static Resultado<T> NoAutorizado(string mensaje) => new(default, TipoError.NoAutorizado, mensaje);
}
