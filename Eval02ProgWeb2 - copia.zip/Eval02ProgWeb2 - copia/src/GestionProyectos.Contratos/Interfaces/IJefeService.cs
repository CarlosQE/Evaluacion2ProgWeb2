using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;

namespace GestionProyectos.Contratos.Interfaces;

public interface IJefeService
{
    Task<List<JefeRespuestaDto>> ListarAsync(string? texto);
    Task<JefeRespuestaDto?> ObtenerAsync(int id);
    Task<Resultado<JefeRespuestaDto>> CrearAsync(JefeCrearDto dto);
}
