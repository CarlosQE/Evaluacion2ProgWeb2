namespace GestionProyectos.Contratos.Interfaces;

public interface IPasswordHasher
{
    string Hashear(string contrasena);
    bool Verificar(string contrasena, string hashGuardado);
}
