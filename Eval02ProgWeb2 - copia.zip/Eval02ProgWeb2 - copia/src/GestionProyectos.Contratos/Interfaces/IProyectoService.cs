using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;

namespace GestionProyectos.Contratos.Interfaces;

public interface IProyectoService
{
    Task<List<ProyectoRespuestaDto>> ListarAsync(string? texto, EstadoProyecto? estado);
    Task<ProyectoRespuestaDto?> ObtenerAsync(int id);
    Task<Resultado<ProyectoRespuestaDto>> CrearAsync(ProyectoCrearDto dto);
    Task<Resultado<ProyectoRespuestaDto>> CambiarEstadoAsync(int id, EstadoProyecto estado);
}
