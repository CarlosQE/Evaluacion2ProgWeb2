using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;

namespace GestionProyectos.Contratos.Interfaces;

public interface IAuthService
{
    Task<Resultado<TokenDto>> IniciarSesionAsync(LoginDto login);
}
