using System.Linq.Expressions;
using GestionProyectos.Api.Data;
using GestionProyectos.Api.Models;
using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;
using GestionProyectos.Contratos.Validaciones;
using Microsoft.EntityFrameworkCore;
using ResultadoProyecto = GestionProyectos.Contratos.Comun.Resultado<GestionProyectos.Contratos.DTOs.ProyectoRespuestaDto>;

namespace GestionProyectos.Api.Services;

public class ProyectoService(GestionProyectosDbContext db) : IProyectoService
{
    private static readonly EstadoProyecto[] Activos = EstadosProyecto.Activos;

    private static readonly Expression<Func<Proyecto, ProyectoRespuestaDto>> ARespuesta = p =>
        new ProyectoRespuestaDto(
            p.Id,
            p.Nombre,
            p.Descripcion,
            p.Estado,
            new JefeResumenDto(p.Jefe.Id, p.Jefe.Nombre, p.Jefe.Cargo, p.Jefe.Correo));

    public Task<List<ProyectoRespuestaDto>> ListarAsync(string? texto, EstadoProyecto? estado)
    {
        var consulta = db.Proyectos.AsNoTracking();
        var filtro = texto?.Trim();

        if (!string.IsNullOrEmpty(filtro))
            consulta = consulta.Where(p => p.Nombre.Contains(filtro) || p.Descripcion.Contains(filtro) || p.Jefe.Nombre.Contains(filtro));
        if (estado is not null)
            consulta = consulta.Where(p => p.Estado == estado);

        return consulta.OrderBy(p => p.Nombre).Select(ARespuesta).ToListAsync();
    }

    public Task<ProyectoRespuestaDto?> ObtenerAsync(int id) =>
        db.Proyectos.AsNoTracking().Where(p => p.Id == id).Select(ARespuesta).FirstOrDefaultAsync();

    public async Task<ResultadoProyecto> CrearAsync(ProyectoCrearDto dto)
    {
        if (!EstadosProyecto.Iniciales.Contains(dto.Estado))
            return ResultadoProyecto.Validacion(
                $"Un proyecto nuevo solo puede crearse como {string.Join(" o ", EstadosProyecto.Iniciales)}.");

        var nombre = Normalizador.PrimeraMayuscula(dto.Nombre);
        var descripcion = Normalizador.Parrafo(dto.Descripcion);

        if (Normalizador.Clave(descripcion) == Normalizador.Clave(nombre))
            return ResultadoProyecto.Validacion("La descripción no puede ser igual al nombre del proyecto.");

        var existente = await db.Proyectos.Where(p => p.Nombre == nombre).Select(p => p.Nombre).FirstOrDefaultAsync();
        if (existente is not null)
            return ResultadoProyecto.Conflicto($"Ya existe un proyecto llamado '{existente}'.");

        if (!await db.Jefes.AnyAsync(j => j.Id == dto.JefeId))
            return ResultadoProyecto.NoEncontrado($"No existe el jefe con Id {dto.JefeId}.");

        if (dto.Estado.EsActivo() && await ValidarJefeLibreAsync(dto.JefeId) is { } ocupado)
            return ocupado;

        var proyecto = new Proyecto
        {
            Nombre = nombre,
            Descripcion = descripcion,
            Estado = dto.Estado,
            JefeId = dto.JefeId,
        };
        db.Proyectos.Add(proyecto);

        if (!await GuardarAsync())
            return ResultadoProyecto.Conflicto("El nombre ya está en uso o el jefe ya tiene un proyecto activo.");

        return ResultadoProyecto.Ok((await ObtenerAsync(proyecto.Id))!);
    }

    public async Task<ResultadoProyecto> CambiarEstadoAsync(int id, EstadoProyecto estado)
    {
        if (!Enum.IsDefined(estado))
            return ResultadoProyecto.Validacion("El estado indicado no es válido.");

        var proyecto = await db.Proyectos.FindAsync(id);
        if (proyecto is null) return ResultadoProyecto.NoEncontrado($"No existe el proyecto con Id {id}.");

        if (proyecto.Estado == estado)
            return ResultadoProyecto.Validacion($"El proyecto ya está en estado {estado}.");

        if (!proyecto.Estado.PuedeCambiarA(estado))
        {
            var permitidos = proyecto.Estado.SiguientesEstados();
            return ResultadoProyecto.Conflicto(permitidos.Count == 0
                ? $"El proyecto está {proyecto.Estado} y ya no puede cambiar de estado."
                : $"Un proyecto {proyecto.Estado} no puede pasar a {estado}. Estados permitidos: {string.Join(", ", permitidos)}.");
        }

        if (estado.EsActivo() && !proyecto.Estado.EsActivo() && await ValidarJefeLibreAsync(proyecto.JefeId) is { } ocupado)
            return ocupado;

        proyecto.Estado = estado;
        if (!await GuardarAsync())
            return ResultadoProyecto.Conflicto("El jefe ya tiene un proyecto activo.");

        return ResultadoProyecto.Ok((await ObtenerAsync(id))!);
    }

    private async Task<ResultadoProyecto?> ValidarJefeLibreAsync(int jefeId)
    {
        var activo = await db.Proyectos
            .Where(p => p.JefeId == jefeId && Activos.Contains(p.Estado))
            .Select(p => new { p.Id, p.Nombre, Jefe = p.Jefe.Nombre })
            .FirstOrDefaultAsync();

        return activo is null
            ? null
            : ResultadoProyecto.Conflicto(
                $"El jefe '{activo.Jefe}' ya tiene a su cargo el proyecto activo '{activo.Nombre}' (Id {activo.Id}). " +
                "Debe finalizarlo o cancelarlo antes de asignarle otro.");
    }

    private async Task<bool> GuardarAsync()
    {
        try
        {
            await db.SaveChangesAsync();
            return true;
        }
        catch (DbUpdateException)
        {
            return false;
        }
    }
}
