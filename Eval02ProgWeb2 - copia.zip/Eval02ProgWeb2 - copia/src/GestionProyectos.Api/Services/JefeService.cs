using System.Linq.Expressions;
using GestionProyectos.Api.Data;
using GestionProyectos.Api.Models;
using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;
using GestionProyectos.Contratos.Validaciones;
using Microsoft.EntityFrameworkCore;

namespace GestionProyectos.Api.Services;

public class JefeService(GestionProyectosDbContext db) : IJefeService
{
    private static readonly EstadoProyecto[] Activos = EstadosProyecto.Activos;

    private static readonly Expression<Func<Jefe, JefeRespuestaDto>> ARespuesta = j =>
        new JefeRespuestaDto(
            j.Id,
            j.Nombre,
            j.Cargo,
            j.Correo,
            j.Proyectos
                .Where(p => Activos.Contains(p.Estado))
                .Select(p => new ProyectoResumenDto(p.Id, p.Nombre, p.Estado))
                .FirstOrDefault());

    public Task<List<JefeRespuestaDto>> ListarAsync(string? texto)
    {
        var consulta = db.Jefes.AsNoTracking();
        var filtro = texto?.Trim();

        if (!string.IsNullOrEmpty(filtro))
            consulta = consulta.Where(j => j.Nombre.Contains(filtro) || j.Cargo.Contains(filtro) || j.Correo.Contains(filtro));

        return consulta.OrderBy(j => j.Nombre).Select(ARespuesta).ToListAsync();
    }

    public Task<JefeRespuestaDto?> ObtenerAsync(int id) =>
        db.Jefes.AsNoTracking().Where(j => j.Id == id).Select(ARespuesta).FirstOrDefaultAsync();

    public async Task<Resultado<JefeRespuestaDto>> CrearAsync(JefeCrearDto dto)
    {
        var nombre = Normalizador.NombrePropio(dto.Nombre);
        var cargo = Normalizador.PrimeraMayuscula(dto.Cargo);
        var correo = Normalizador.Correo(dto.Correo);

        var existente = await db.Jefes.Where(j => j.Nombre == nombre).Select(j => j.Nombre).FirstOrDefaultAsync();
        if (existente is not null)
            return Resultado<JefeRespuestaDto>.Conflicto($"Ya existe un jefe llamado '{existente}'.");

        var correoExistente = await db.Jefes.Where(j => j.Correo == correo).Select(j => j.Nombre).FirstOrDefaultAsync();
        if (correoExistente is not null)
            return Resultado<JefeRespuestaDto>.Conflicto($"El correo '{correo}' ya pertenece al jefe '{correoExistente}'.");

        var jefe = new Jefe { Nombre = nombre, Cargo = cargo, Correo = correo };
        db.Jefes.Add(jefe);

        try
        {
            await db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            return Resultado<JefeRespuestaDto>.Conflicto("Ya existe un jefe con ese nombre o correo.");
        }

        return Resultado<JefeRespuestaDto>.Ok((await ObtenerAsync(jefe.Id))!);
    }
}
