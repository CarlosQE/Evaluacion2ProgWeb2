using System.Security.Claims;
using System.Text;
using GestionProyectos.Api.Interfaces;
using GestionProyectos.Api.Models;
using GestionProyectos.Api.Seguridad;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;

namespace GestionProyectos.Api.Services;

public class TokenService(IOptions<JwtOpciones> opciones) : ITokenService
{
    private readonly JwtOpciones _jwt = opciones.Value;

    public (string Token, DateTime ExpiraEnUtc) Generar(Usuario usuario)
    {
        var expira = DateTime.UtcNow.AddMinutes(_jwt.MinutosExpiracion);
        var credenciales = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwt.Clave)), SecurityAlgorithms.HmacSha256);

        var descriptor = new SecurityTokenDescriptor
        {
            Issuer = _jwt.Emisor,
            Audience = _jwt.Audiencia,
            Expires = expira,
            SigningCredentials = credenciales,
            Subject = new ClaimsIdentity(
            [
                new Claim(JwtRegisteredClaimNames.Sub, usuario.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.UniqueName, usuario.NombreUsuario),
                new Claim(JwtRegisteredClaimNames.Name, usuario.NombreCompleto),
                new Claim(ClaimTypes.Role, usuario.Rol),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            ]),
        };

        return (new JsonWebTokenHandler().CreateToken(descriptor), expira);
    }
}
