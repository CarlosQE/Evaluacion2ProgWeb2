using GestionProyectos.Api.Data;
using GestionProyectos.Api.Interfaces;
using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace GestionProyectos.Api.Services;

public class AuthService(GestionProyectosDbContext db, IPasswordHasher hasher, ITokenService tokens) : IAuthService
{
    public async Task<Resultado<TokenDto>> IniciarSesionAsync(LoginDto login)
    {
        var nombreUsuario = login.NombreUsuario.Trim();
        var usuario = await db.Usuarios.AsNoTracking().FirstOrDefaultAsync(u => u.NombreUsuario == nombreUsuario);

        if (usuario is null || !hasher.Verificar(login.Contrasena, usuario.PasswordHash))
            return Resultado<TokenDto>.NoAutorizado("Usuario o contraseña incorrectos.");

        var (token, expira) = tokens.Generar(usuario);
        return Resultado<TokenDto>.Ok(new TokenDto(
            token,
            expira,
            new UsuarioDto(usuario.Id, usuario.NombreUsuario, usuario.NombreCompleto, usuario.Rol)));
    }
}
