using GestionProyectos.Api.Models;

namespace GestionProyectos.Api.Interfaces;

public interface ITokenService
{
    (string Token, DateTime ExpiraEnUtc) Generar(Usuario usuario);
}
