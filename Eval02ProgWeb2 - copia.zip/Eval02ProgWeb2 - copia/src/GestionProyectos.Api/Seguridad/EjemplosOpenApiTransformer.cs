using System.Text.Json.Nodes;
using GestionProyectos.Contratos.DTOs;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.OpenApi;

namespace GestionProyectos.Api.Seguridad;

internal sealed class EjemplosOpenApiTransformer : IOpenApiSchemaTransformer
{
    private static readonly Dictionary<Type, string> Ejemplos = new()
    {
        [typeof(LoginDto)] = """{ "nombreUsuario": "admin", "contrasena": "Admin2026" }""",
        [typeof(JefeCrearDto)] = """{ "nombre": "Carolina Vega", "cargo": "Jefe de Proyectos", "correo": "carolina.vega@gestionproyectos.com" }""",
        [typeof(ProyectoCrearDto)] = """{ "nombre": "Intranet Corporativa", "descripcion": "Portal interno para la comunicación con los empleados.", "jefeId": 11, "estado": "Planificado" }""",
        [typeof(ProyectoCambiarEstadoDto)] = """{ "estado": "Finalizado" }""",
    };

    public Task TransformAsync(OpenApiSchema schema, OpenApiSchemaTransformerContext context, CancellationToken cancellationToken)
    {
        if (Ejemplos.TryGetValue(context.JsonTypeInfo.Type, out var json))
            schema.Examples = [JsonNode.Parse(json)!];

        if (context.JsonTypeInfo.Type == typeof(EstadoProyecto))
            schema.Description = "Texto entre comillas. Valores: " + string.Join(", ", Enum.GetNames<EstadoProyecto>()) +
                                 ". Al crear solo se permite Planificado o EnProgreso.";

        return Task.CompletedTask;
    }
}
