using System.Security.Cryptography;
using System.Text;
using GestionProyectos.Contratos.Interfaces;

namespace GestionProyectos.Api.Seguridad;

public class PasswordHasher : IPasswordHasher
{
    private const int Iteraciones = 100_000;
    private const int LargoSal = 16;
    private const int LargoHash = 32;

    public string Hashear(string contrasena) => Hashear(contrasena, RandomNumberGenerator.GetBytes(LargoSal));

    public static string HashearDeterminista(string contrasena, string semillaSal) =>
        Hashear(contrasena, SHA256.HashData(Encoding.UTF8.GetBytes(semillaSal))[..LargoSal]);

    private static string Hashear(string contrasena, byte[] sal)
    {
        var hash = Rfc2898DeriveBytes.Pbkdf2(contrasena, sal, Iteraciones, HashAlgorithmName.SHA256, LargoHash);
        return $"{Iteraciones}.{Convert.ToBase64String(sal)}.{Convert.ToBase64String(hash)}";
    }

    public bool Verificar(string contrasena, string hashGuardado)
    {
        var partes = hashGuardado.Split('.');
        if (partes.Length != 3 || !int.TryParse(partes[0], out var iteraciones)) return false;

        var sal = Convert.FromBase64String(partes[1]);
        var esperado = Convert.FromBase64String(partes[2]);
        var calculado = Rfc2898DeriveBytes.Pbkdf2(contrasena, sal, iteraciones, HashAlgorithmName.SHA256, esperado.Length);

        return CryptographicOperations.FixedTimeEquals(calculado, esperado);
    }
}
