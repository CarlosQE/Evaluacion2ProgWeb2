namespace GestionProyectos.Api.Seguridad;

public static class Roles
{
    public const string Administrador = "Administrador";
    public const string Gestor = "Gestor";
}
