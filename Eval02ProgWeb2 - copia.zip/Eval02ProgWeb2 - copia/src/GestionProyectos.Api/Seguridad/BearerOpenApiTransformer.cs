using Microsoft.AspNetCore.OpenApi;
using Microsoft.OpenApi;

namespace GestionProyectos.Api.Seguridad;

internal sealed class BearerOpenApiTransformer : IOpenApiDocumentTransformer
{
    public const string Esquema = "Bearer";

    public Task TransformAsync(OpenApiDocument document, OpenApiDocumentTransformerContext context, CancellationToken cancellationToken)
    {
        document.Components ??= new OpenApiComponents();
        document.Components.SecuritySchemes ??= new Dictionary<string, IOpenApiSecurityScheme>();
        document.Components.SecuritySchemes[Esquema] = new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.Http,
            Scheme = "bearer",
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Description = "Pegue aquí el token obtenido en POST /api/auth/login (sin la palabra 'Bearer').",
        };

        document.Security ??= [];
        document.Security.Add(new OpenApiSecurityRequirement
        {
            [new OpenApiSecuritySchemeReference(Esquema, document)] = [],
        });

        return Task.CompletedTask;
    }
}
