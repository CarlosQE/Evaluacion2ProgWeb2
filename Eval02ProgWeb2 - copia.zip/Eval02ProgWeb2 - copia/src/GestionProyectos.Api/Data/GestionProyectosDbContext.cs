using GestionProyectos.Api.Data.Seeds;
using GestionProyectos.Api.Models;
using GestionProyectos.Contratos.DTOs;
using Microsoft.EntityFrameworkCore;

namespace GestionProyectos.Api.Data;

public class GestionProyectosDbContext(DbContextOptions<GestionProyectosDbContext> options) : DbContext(options)
{
    public DbSet<Jefe> Jefes => Set<Jefe>();
    public DbSet<Proyecto> Proyectos => Set<Proyecto>();
    public DbSet<Usuario> Usuarios => Set<Usuario>();

    private const string ColacionSinTildes = "Modern_Spanish_CI_AI";

    private static readonly string FiltroEstadosActivos =
        $"[Estado] IN ({string.Join(", ", EstadosProyecto.Activos.Select(e => $"'{e}'"))})";

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Jefe>(e =>
        {
            e.Property(x => x.Nombre).HasMaxLength(100).UseCollation(ColacionSinTildes);
            e.Property(x => x.Cargo).HasMaxLength(80);
            e.Property(x => x.Correo).HasMaxLength(120).UseCollation(ColacionSinTildes);

            e.HasIndex(x => x.Nombre).IsUnique();
            e.HasIndex(x => x.Correo).IsUnique();

            e.ToTable(t =>
            {
                t.HasCheckConstraint("CK_Jefes_Nombre", "LEN(LTRIM(RTRIM([Nombre]))) >= 5 AND [Nombre] NOT LIKE '%[0-9]%'");
                t.HasCheckConstraint("CK_Jefes_Cargo", "LEN(LTRIM(RTRIM([Cargo]))) >= 2 AND [Cargo] NOT LIKE '%[0-9]%'");
                t.HasCheckConstraint("CK_Jefes_Correo", "[Correo] LIKE '_%@_%._%' AND [Correo] NOT LIKE '% %'");
            });
        });

        modelBuilder.Entity<Proyecto>(e =>
        {
            e.Property(x => x.Nombre).HasMaxLength(120).UseCollation(ColacionSinTildes);
            e.Property(x => x.Descripcion).HasMaxLength(500);
            e.Property(x => x.Estado).HasConversion<string>().HasMaxLength(20);

            e.ToTable(t =>
            {
                t.HasCheckConstraint("CK_Proyectos_Nombre", "LEN(LTRIM(RTRIM([Nombre]))) >= 3");
                t.HasCheckConstraint("CK_Proyectos_Descripcion", "LEN(LTRIM(RTRIM([Descripcion]))) >= 10");
                t.HasCheckConstraint("CK_Proyectos_Estado",
                    $"[Estado] IN ({string.Join(", ", Enum.GetNames<EstadoProyecto>().Select(n => $"'{n}'"))})");
            });

            e.HasOne(x => x.Jefe)
                .WithMany(j => j.Proyectos)
                .HasForeignKey(x => x.JefeId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasIndex(x => x.Nombre).IsUnique();

            e.HasIndex(x => x.JefeId)
                .IsUnique()
                .HasFilter(FiltroEstadosActivos)
                .HasDatabaseName("UX_Proyectos_JefeActivo");
        });

        modelBuilder.Entity<Usuario>(e =>
        {
            e.Property(x => x.NombreUsuario).HasMaxLength(40);
            e.Property(x => x.NombreCompleto).HasMaxLength(100);
            e.Property(x => x.PasswordHash).HasMaxLength(200);
            e.Property(x => x.Rol).HasMaxLength(30);
            e.HasIndex(x => x.NombreUsuario).IsUnique();
        });

        JefeSeed.Aplicar(modelBuilder);
        ProyectoSeed.Aplicar(modelBuilder);
        UsuarioSeed.Aplicar(modelBuilder);
    }
}
