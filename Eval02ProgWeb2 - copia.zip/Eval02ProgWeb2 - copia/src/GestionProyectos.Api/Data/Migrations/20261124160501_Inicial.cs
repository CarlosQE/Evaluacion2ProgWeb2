using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814

namespace GestionProyectos.Api.Data.Migrations
{
    public partial class Inicial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Jefes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Cargo = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    Correo = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Jefes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Usuarios",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NombreUsuario = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    NombreCompleto = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Rol = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Usuarios", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Proyectos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    Descripcion = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Estado = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    JefeId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Proyectos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Proyectos_Jefes_JefeId",
                        column: x => x.JefeId,
                        principalTable: "Jefes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Jefes",
                columns: new[] { "Id", "Cargo", "Correo", "Nombre" },
                values: new object[,]
                {
                    { 1, "Gerente de Proyectos", "andres.gutierrez@gestionproyectos.com", "Andrés Gutiérrez" },
                    { 2, "Líder Técnico", "lucia.rojas@gestionproyectos.com", "Lucía Rojas" },
                    { 3, "Jefe de Desarrollo", "fernando.mendoza@gestionproyectos.com", "Fernando Mendoza" },
                    { 4, "Arquitecto de Software", "valeria.vargas@gestionproyectos.com", "Valeria Vargas" },
                    { 5, "Scrum Master", "rodrigo.salazar@gestionproyectos.com", "Rodrigo Salazar" },
                    { 6, "Jefe de Operaciones", "camila.quiroga@gestionproyectos.com", "Camila Quiroga" },
                    { 7, "Coordinador de TI", "mauricio.cespedes@gestionproyectos.com", "Mauricio Céspedes" },
                    { 8, "Jefe de Infraestructura", "daniela.montano@gestionproyectos.com", "Daniela Montaño" },
                    { 9, "Product Owner", "gonzalo.antezana@gestionproyectos.com", "Gonzalo Antezana" },
                    { 10, "Director de Tecnología", "paola.villarroel@gestionproyectos.com", "Paola Villarroel" },
                    { 11, "Gerente de Proyectos", "sergio.saavedra@gestionproyectos.com", "Sergio Saavedra" },
                    { 12, "Líder Técnico", "mariana.zambrana@gestionproyectos.com", "Mariana Zambrana" }
                });

            migrationBuilder.InsertData(
                table: "Usuarios",
                columns: new[] { "Id", "NombreCompleto", "NombreUsuario", "PasswordHash", "Rol" },
                values: new object[,]
                {
                    { 1, "Administrador General", "admin", "100000.bkJ4swfKFBOQbc+wI7gZRg==.w6UyakDm7iNWcjBkRa6KXGIvvglLQOBLNKIos7b70kc=", "Administrador" },
                    { 2, "Carla Fernández", "gestor01", "100000.R6yDFBm/Lhd4Bxx5UyKO7Q==.rM+pj5FgtS5yHidSbCEYAMoFU8DsY1lJuxvLl2vKHU4=", "Gestor" },
                    { 3, "Jorge Mamani", "gestor02", "100000.dV/bovB3fSAA28He8D6SMw==.iCTfglMIc7fMNSGtcFKC/0wdQP3FI27IKpRnFXOMvTM=", "Gestor" },
                    { 4, "Sofía Ríos", "gestor03", "100000.ZXSFfnXsKDCXSwoUe1Ibpg==.ltHiJzkdpMiuEHzTfYBTdkj/O9Vp1VvpCOcEx/2mMTM=", "Gestor" },
                    { 5, "Diego Paredes", "gestor04", "100000.6xGvzurQtVQwo5ePLvFU2Q==.ErasHT5C8hMWgvwwdmf3JauViX9JKsdydD5GyHDGzeU=", "Gestor" },
                    { 6, "Elena Castro", "gestor05", "100000.CSAnPK4s11KuROtJ9i5kxw==.wG6PGdRjwu+RN1pzxdnzbA0RFu7nkYkMmXj2r+lneXw=", "Gestor" },
                    { 7, "Hugo Medina", "gestor06", "100000.M1io1U8rTWNfQFjZDJXJYw==.EJJ++9zfA91fNvXzziRnLEH26ncGd4ddY3U+2kZUAJo=", "Gestor" },
                    { 8, "Inés Delgado", "gestor07", "100000.kraRy+dFY1t06D+7BSk8+Q==.KE1OAYmRR9Wk3b1xOtMOVWbTaZfPWdmZ/NLL8VgVynA=", "Gestor" },
                    { 9, "Óscar Rivera", "gestor08", "100000.EX8XhgRbwBgH7tdWK+F9RQ==.mrTSxVqPlGKoB5GxwjlnYKbJNTBE3s2/XU3LeaNdPJE=", "Gestor" },
                    { 10, "Patricia Molina", "gestor09", "100000.6KWbXKOxxUOc3tnms+y3nw==.lsIthzKStpaG39dZsLTImFT9rk12ou2TjYTrA+0QUQo=", "Gestor" },
                    { 11, "Raúl Herrera", "gestor10", "100000.JOSrjC2KGM7fy4E79gkeaA==.dACPBEqQZ4oodSM4G/sGPpCsk7XNpzWeKKak18hg7Mk=", "Gestor" }
                });

            migrationBuilder.InsertData(
                table: "Proyectos",
                columns: new[] { "Id", "Descripcion", "Estado", "JefeId", "Nombre" },
                values: new object[,]
                {
                    { 1, "Portal Web para el área de Ventas que busca centralizar la información y reducir tiempos de respuesta.", "EnProgreso", 1, "Portal Web de Ventas" },
                    { 2, "App Móvil para el área de Recursos Humanos que busca automatizar tareas manuales repetitivas.", "Planificado", 2, "App Móvil de Recursos Humanos" },
                    { 3, "Sistema para el área de Logística que busca mejorar la trazabilidad de cada operación.", "Pausado", 3, "Sistema de Logística" },
                    { 4, "Plataforma para el área de Finanzas que busca ofrecer reportes en tiempo real a la gerencia.", "EnProgreso", 4, "Plataforma de Finanzas" },
                    { 5, "Migración a la Nube para el área de Inventario que busca reducir costos operativos del área.", "Planificado", 5, "Migración a la Nube de Inventario" },
                    { 6, "Dashboard para el área de Atención al Cliente que busca centralizar la información y reducir tiempos de respuesta.", "Pausado", 6, "Dashboard de Atención al Cliente" },
                    { 7, "API para el área de Marketing que busca automatizar tareas manuales repetitivas.", "EnProgreso", 7, "API de Marketing" },
                    { 8, "Automatización para el área de Compras que busca mejorar la trazabilidad de cada operación.", "Planificado", 8, "Automatización de Compras" },
                    { 9, "Módulo para el área de Producción que busca ofrecer reportes en tiempo real a la gerencia.", "Pausado", 9, "Módulo de Producción" },
                    { 10, "Rediseño para el área de Calidad que busca reducir costos operativos del área.", "EnProgreso", 10, "Rediseño de Calidad" },
                    { 11, "Portal Web para el área de Recursos Humanos que busca centralizar la información y reducir tiempos de respuesta.", "Finalizado", 1, "Portal Web de Recursos Humanos" },
                    { 12, "App Móvil para el área de Logística que busca automatizar tareas manuales repetitivas.", "Cancelado", 2, "App Móvil de Logística" },
                    { 13, "Sistema para el área de Finanzas que busca mejorar la trazabilidad de cada operación.", "Finalizado", 3, "Sistema de Finanzas" },
                    { 14, "Plataforma para el área de Inventario que busca ofrecer reportes en tiempo real a la gerencia.", "Cancelado", 4, "Plataforma de Inventario" },
                    { 15, "Migración a la Nube para el área de Atención al Cliente que busca reducir costos operativos del área.", "Finalizado", 5, "Migración a la Nube de Atención al Cliente" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Jefes_Correo",
                table: "Jefes",
                column: "Correo",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Jefes_Nombre",
                table: "Jefes",
                column: "Nombre",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Proyectos_Nombre",
                table: "Proyectos",
                column: "Nombre",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_Proyectos_JefeActivo",
                table: "Proyectos",
                column: "JefeId",
                unique: true,
                filter: "[Estado] IN ('Planificado', 'EnProgreso', 'Pausado')");

            migrationBuilder.CreateIndex(
                name: "IX_Usuarios_NombreUsuario",
                table: "Usuarios",
                column: "NombreUsuario",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Proyectos");

            migrationBuilder.DropTable(
                name: "Usuarios");

            migrationBuilder.DropTable(
                name: "Jefes");
        }
    }
}
