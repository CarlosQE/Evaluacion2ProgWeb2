using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GestionProyectos.Api.Data.Migrations
{
    public partial class ValidacionesDatos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Nombre",
                table: "Proyectos",
                type: "nvarchar(120)",
                maxLength: 120,
                nullable: false,
                collation: "Modern_Spanish_CI_AI",
                oldClrType: typeof(string),
                oldType: "nvarchar(120)",
                oldMaxLength: 120);

            migrationBuilder.AlterColumn<string>(
                name: "Nombre",
                table: "Jefes",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                collation: "Modern_Spanish_CI_AI",
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "Correo",
                table: "Jefes",
                type: "nvarchar(120)",
                maxLength: 120,
                nullable: false,
                collation: "Modern_Spanish_CI_AI",
                oldClrType: typeof(string),
                oldType: "nvarchar(120)",
                oldMaxLength: 120);

            migrationBuilder.AddCheckConstraint(
                name: "CK_Proyectos_Descripcion",
                table: "Proyectos",
                sql: "LEN(LTRIM(RTRIM([Descripcion]))) >= 10");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Proyectos_Estado",
                table: "Proyectos",
                sql: "[Estado] IN ('Planificado', 'EnProgreso', 'Pausado', 'Finalizado', 'Cancelado')");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Proyectos_Nombre",
                table: "Proyectos",
                sql: "LEN(LTRIM(RTRIM([Nombre]))) >= 3");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Jefes_Cargo",
                table: "Jefes",
                sql: "LEN(LTRIM(RTRIM([Cargo]))) >= 2 AND [Cargo] NOT LIKE '%[0-9]%'");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Jefes_Correo",
                table: "Jefes",
                sql: "[Correo] LIKE '_%@_%._%' AND [Correo] NOT LIKE '% %'");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Jefes_Nombre",
                table: "Jefes",
                sql: "LEN(LTRIM(RTRIM([Nombre]))) >= 5 AND [Nombre] NOT LIKE '%[0-9]%'");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CK_Proyectos_Descripcion",
                table: "Proyectos");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Proyectos_Estado",
                table: "Proyectos");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Proyectos_Nombre",
                table: "Proyectos");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Jefes_Cargo",
                table: "Jefes");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Jefes_Correo",
                table: "Jefes");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Jefes_Nombre",
                table: "Jefes");

            migrationBuilder.AlterColumn<string>(
                name: "Nombre",
                table: "Proyectos",
                type: "nvarchar(120)",
                maxLength: 120,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(120)",
                oldMaxLength: 120,
                oldCollation: "Modern_Spanish_CI_AI");

            migrationBuilder.AlterColumn<string>(
                name: "Nombre",
                table: "Jefes",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldCollation: "Modern_Spanish_CI_AI");

            migrationBuilder.AlterColumn<string>(
                name: "Correo",
                table: "Jefes",
                type: "nvarchar(120)",
                maxLength: 120,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(120)",
                oldMaxLength: 120,
                oldCollation: "Modern_Spanish_CI_AI");
        }
    }
}
