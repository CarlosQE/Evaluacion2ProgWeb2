using GestionProyectos.Api.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

#nullable disable

namespace GestionProyectos.Api.Data.Migrations
{
    [DbContext(typeof(GestionProyectosDbContext))]
    partial class GestionProyectosDbContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder
                .HasAnnotation("ProductVersion", "10.0.14")
                .HasAnnotation("Relational:MaxIdentifierLength", 128);

            SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);

            modelBuilder.Entity("GestionProyectos.Api.Models.Jefe", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<string>("Cargo")
                        .IsRequired()
                        .HasMaxLength(80)
                        .HasColumnType("nvarchar(80)");

                    b.Property<string>("Correo")
                        .IsRequired()
                        .HasMaxLength(120)
                        .HasColumnType("nvarchar(120)")
                        .UseCollation("Modern_Spanish_CI_AI");

                    b.Property<string>("Nombre")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("nvarchar(100)")
                        .UseCollation("Modern_Spanish_CI_AI");

                    b.HasKey("Id");

                    b.HasIndex("Correo")
                        .IsUnique();

                    b.HasIndex("Nombre")
                        .IsUnique();

                    b.ToTable("Jefes", t =>
                        {
                            t.HasCheckConstraint("CK_Jefes_Cargo", "LEN(LTRIM(RTRIM([Cargo]))) >= 2 AND [Cargo] NOT LIKE '%[0-9]%'");

                            t.HasCheckConstraint("CK_Jefes_Correo", "[Correo] LIKE '_%@_%._%' AND [Correo] NOT LIKE '% %'");

                            t.HasCheckConstraint("CK_Jefes_Nombre", "LEN(LTRIM(RTRIM([Nombre]))) >= 5 AND [Nombre] NOT LIKE '%[0-9]%'");
                        });

                    b.HasData(
                        new
                        {
                            Id = 1,
                            Cargo = "Gerente de Proyectos",
                            Correo = "andres.gutierrez@gestionproyectos.com",
                            Nombre = "Andrés Gutiérrez"
                        },
                        new
                        {
                            Id = 2,
                            Cargo = "Líder Técnico",
                            Correo = "lucia.rojas@gestionproyectos.com",
                            Nombre = "Lucía Rojas"
                        },
                        new
                        {
                            Id = 3,
                            Cargo = "Jefe de Desarrollo",
                            Correo = "fernando.mendoza@gestionproyectos.com",
                            Nombre = "Fernando Mendoza"
                        },
                        new
                        {
                            Id = 4,
                            Cargo = "Arquitecto de Software",
                            Correo = "valeria.vargas@gestionproyectos.com",
                            Nombre = "Valeria Vargas"
                        },
                        new
                        {
                            Id = 5,
                            Cargo = "Scrum Master",
                            Correo = "rodrigo.salazar@gestionproyectos.com",
                            Nombre = "Rodrigo Salazar"
                        },
                        new
                        {
                            Id = 6,
                            Cargo = "Jefe de Operaciones",
                            Correo = "camila.quiroga@gestionproyectos.com",
                            Nombre = "Camila Quiroga"
                        },
                        new
                        {
                            Id = 7,
                            Cargo = "Coordinador de TI",
                            Correo = "mauricio.cespedes@gestionproyectos.com",
                            Nombre = "Mauricio Céspedes"
                        },
                        new
                        {
                            Id = 8,
                            Cargo = "Jefe de Infraestructura",
                            Correo = "daniela.montano@gestionproyectos.com",
                            Nombre = "Daniela Montaño"
                        },
                        new
                        {
                            Id = 9,
                            Cargo = "Product Owner",
                            Correo = "gonzalo.antezana@gestionproyectos.com",
                            Nombre = "Gonzalo Antezana"
                        },
                        new
                        {
                            Id = 10,
                            Cargo = "Director de Tecnología",
                            Correo = "paola.villarroel@gestionproyectos.com",
                            Nombre = "Paola Villarroel"
                        },
                        new
                        {
                            Id = 11,
                            Cargo = "Gerente de Proyectos",
                            Correo = "sergio.saavedra@gestionproyectos.com",
                            Nombre = "Sergio Saavedra"
                        },
                        new
                        {
                            Id = 12,
                            Cargo = "Líder Técnico",
                            Correo = "mariana.zambrana@gestionproyectos.com",
                            Nombre = "Mariana Zambrana"
                        });
                });

            modelBuilder.Entity("GestionProyectos.Api.Models.Proyecto", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<string>("Descripcion")
                        .IsRequired()
                        .HasMaxLength(500)
                        .HasColumnType("nvarchar(500)");

                    b.Property<string>("Estado")
                        .IsRequired()
                        .HasMaxLength(20)
                        .HasColumnType("nvarchar(20)");

                    b.Property<int>("JefeId")
                        .HasColumnType("int");

                    b.Property<string>("Nombre")
                        .IsRequired()
                        .HasMaxLength(120)
                        .HasColumnType("nvarchar(120)")
                        .UseCollation("Modern_Spanish_CI_AI");

                    b.HasKey("Id");

                    b.HasIndex("JefeId")
                        .IsUnique()
                        .HasDatabaseName("UX_Proyectos_JefeActivo")
                        .HasFilter("[Estado] IN ('Planificado', 'EnProgreso', 'Pausado')");

                    b.HasIndex("Nombre")
                        .IsUnique();

                    b.ToTable("Proyectos", t =>
                        {
                            t.HasCheckConstraint("CK_Proyectos_Descripcion", "LEN(LTRIM(RTRIM([Descripcion]))) >= 10");

                            t.HasCheckConstraint("CK_Proyectos_Estado", "[Estado] IN ('Planificado', 'EnProgreso', 'Pausado', 'Finalizado', 'Cancelado')");

                            t.HasCheckConstraint("CK_Proyectos_Nombre", "LEN(LTRIM(RTRIM([Nombre]))) >= 3");
                        });

                    b.HasData(
                        new
                        {
                            Id = 1,
                            Descripcion = "Portal Web para el área de Ventas que busca centralizar la información y reducir tiempos de respuesta.",
                            Estado = "EnProgreso",
                            JefeId = 1,
                            Nombre = "Portal Web de Ventas"
                        },
                        new
                        {
                            Id = 2,
                            Descripcion = "App Móvil para el área de Recursos Humanos que busca automatizar tareas manuales repetitivas.",
                            Estado = "Planificado",
                            JefeId = 2,
                            Nombre = "App Móvil de Recursos Humanos"
                        },
                        new
                        {
                            Id = 3,
                            Descripcion = "Sistema para el área de Logística que busca mejorar la trazabilidad de cada operación.",
                            Estado = "Pausado",
                            JefeId = 3,
                            Nombre = "Sistema de Logística"
                        },
                        new
                        {
                            Id = 4,
                            Descripcion = "Plataforma para el área de Finanzas que busca ofrecer reportes en tiempo real a la gerencia.",
                            Estado = "EnProgreso",
                            JefeId = 4,
                            Nombre = "Plataforma de Finanzas"
                        },
                        new
                        {
                            Id = 5,
                            Descripcion = "Migración a la Nube para el área de Inventario que busca reducir costos operativos del área.",
                            Estado = "Planificado",
                            JefeId = 5,
                            Nombre = "Migración a la Nube de Inventario"
                        },
                        new
                        {
                            Id = 6,
                            Descripcion = "Dashboard para el área de Atención al Cliente que busca centralizar la información y reducir tiempos de respuesta.",
                            Estado = "Pausado",
                            JefeId = 6,
                            Nombre = "Dashboard de Atención al Cliente"
                        },
                        new
                        {
                            Id = 7,
                            Descripcion = "API para el área de Marketing que busca automatizar tareas manuales repetitivas.",
                            Estado = "EnProgreso",
                            JefeId = 7,
                            Nombre = "API de Marketing"
                        },
                        new
                        {
                            Id = 8,
                            Descripcion = "Automatización para el área de Compras que busca mejorar la trazabilidad de cada operación.",
                            Estado = "Planificado",
                            JefeId = 8,
                            Nombre = "Automatización de Compras"
                        },
                        new
                        {
                            Id = 9,
                            Descripcion = "Módulo para el área de Producción que busca ofrecer reportes en tiempo real a la gerencia.",
                            Estado = "Pausado",
                            JefeId = 9,
                            Nombre = "Módulo de Producción"
                        },
                        new
                        {
                            Id = 10,
                            Descripcion = "Rediseño para el área de Calidad que busca reducir costos operativos del área.",
                            Estado = "EnProgreso",
                            JefeId = 10,
                            Nombre = "Rediseño de Calidad"
                        },
                        new
                        {
                            Id = 11,
                            Descripcion = "Portal Web para el área de Recursos Humanos que busca centralizar la información y reducir tiempos de respuesta.",
                            Estado = "Finalizado",
                            JefeId = 1,
                            Nombre = "Portal Web de Recursos Humanos"
                        },
                        new
                        {
                            Id = 12,
                            Descripcion = "App Móvil para el área de Logística que busca automatizar tareas manuales repetitivas.",
                            Estado = "Cancelado",
                            JefeId = 2,
                            Nombre = "App Móvil de Logística"
                        },
                        new
                        {
                            Id = 13,
                            Descripcion = "Sistema para el área de Finanzas que busca mejorar la trazabilidad de cada operación.",
                            Estado = "Finalizado",
                            JefeId = 3,
                            Nombre = "Sistema de Finanzas"
                        },
                        new
                        {
                            Id = 14,
                            Descripcion = "Plataforma para el área de Inventario que busca ofrecer reportes en tiempo real a la gerencia.",
                            Estado = "Cancelado",
                            JefeId = 4,
                            Nombre = "Plataforma de Inventario"
                        },
                        new
                        {
                            Id = 15,
                            Descripcion = "Migración a la Nube para el área de Atención al Cliente que busca reducir costos operativos del área.",
                            Estado = "Finalizado",
                            JefeId = 5,
                            Nombre = "Migración a la Nube de Atención al Cliente"
                        });
                });

            modelBuilder.Entity("GestionProyectos.Api.Models.Usuario", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<string>("NombreCompleto")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("nvarchar(100)");

                    b.Property<string>("NombreUsuario")
                        .IsRequired()
                        .HasMaxLength(40)
                        .HasColumnType("nvarchar(40)");

                    b.Property<string>("PasswordHash")
                        .IsRequired()
                        .HasMaxLength(200)
                        .HasColumnType("nvarchar(200)");

                    b.Property<string>("Rol")
                        .IsRequired()
                        .HasMaxLength(30)
                        .HasColumnType("nvarchar(30)");

                    b.HasKey("Id");

                    b.HasIndex("NombreUsuario")
                        .IsUnique();

                    b.ToTable("Usuarios");

                    b.HasData(
                        new
                        {
                            Id = 1,
                            NombreCompleto = "Administrador General",
                            NombreUsuario = "admin",
                            PasswordHash = "100000.bkJ4swfKFBOQbc+wI7gZRg==.w6UyakDm7iNWcjBkRa6KXGIvvglLQOBLNKIos7b70kc=",
                            Rol = "Administrador"
                        },
                        new
                        {
                            Id = 2,
                            NombreCompleto = "Carla Fernández",
                            NombreUsuario = "gestor01",
                            PasswordHash = "100000.R6yDFBm/Lhd4Bxx5UyKO7Q==.rM+pj5FgtS5yHidSbCEYAMoFU8DsY1lJuxvLl2vKHU4=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 3,
                            NombreCompleto = "Jorge Mamani",
                            NombreUsuario = "gestor02",
                            PasswordHash = "100000.dV/bovB3fSAA28He8D6SMw==.iCTfglMIc7fMNSGtcFKC/0wdQP3FI27IKpRnFXOMvTM=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 4,
                            NombreCompleto = "Sofía Ríos",
                            NombreUsuario = "gestor03",
                            PasswordHash = "100000.ZXSFfnXsKDCXSwoUe1Ibpg==.ltHiJzkdpMiuEHzTfYBTdkj/O9Vp1VvpCOcEx/2mMTM=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 5,
                            NombreCompleto = "Diego Paredes",
                            NombreUsuario = "gestor04",
                            PasswordHash = "100000.6xGvzurQtVQwo5ePLvFU2Q==.ErasHT5C8hMWgvwwdmf3JauViX9JKsdydD5GyHDGzeU=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 6,
                            NombreCompleto = "Elena Castro",
                            NombreUsuario = "gestor05",
                            PasswordHash = "100000.CSAnPK4s11KuROtJ9i5kxw==.wG6PGdRjwu+RN1pzxdnzbA0RFu7nkYkMmXj2r+lneXw=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 7,
                            NombreCompleto = "Hugo Medina",
                            NombreUsuario = "gestor06",
                            PasswordHash = "100000.M1io1U8rTWNfQFjZDJXJYw==.EJJ++9zfA91fNvXzziRnLEH26ncGd4ddY3U+2kZUAJo=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 8,
                            NombreCompleto = "Inés Delgado",
                            NombreUsuario = "gestor07",
                            PasswordHash = "100000.kraRy+dFY1t06D+7BSk8+Q==.KE1OAYmRR9Wk3b1xOtMOVWbTaZfPWdmZ/NLL8VgVynA=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 9,
                            NombreCompleto = "Óscar Rivera",
                            NombreUsuario = "gestor08",
                            PasswordHash = "100000.EX8XhgRbwBgH7tdWK+F9RQ==.mrTSxVqPlGKoB5GxwjlnYKbJNTBE3s2/XU3LeaNdPJE=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 10,
                            NombreCompleto = "Patricia Molina",
                            NombreUsuario = "gestor09",
                            PasswordHash = "100000.6KWbXKOxxUOc3tnms+y3nw==.lsIthzKStpaG39dZsLTImFT9rk12ou2TjYTrA+0QUQo=",
                            Rol = "Gestor"
                        },
                        new
                        {
                            Id = 11,
                            NombreCompleto = "Raúl Herrera",
                            NombreUsuario = "gestor10",
                            PasswordHash = "100000.JOSrjC2KGM7fy4E79gkeaA==.dACPBEqQZ4oodSM4G/sGPpCsk7XNpzWeKKak18hg7Mk=",
                            Rol = "Gestor"
                        });
                });

            modelBuilder.Entity("GestionProyectos.Api.Models.Proyecto", b =>
                {
                    b.HasOne("GestionProyectos.Api.Models.Jefe", "Jefe")
                        .WithMany("Proyectos")
                        .HasForeignKey("JefeId")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.Navigation("Jefe");
                });

            modelBuilder.Entity("GestionProyectos.Api.Models.Jefe", b =>
                {
                    b.Navigation("Proyectos");
                });
#pragma warning restore 612, 618
        }
    }
}
