using GestionProyectos.Api.Data.Factories;
using GestionProyectos.Api.Models;
using GestionProyectos.Contratos.DTOs;
using Microsoft.EntityFrameworkCore;

namespace GestionProyectos.Api.Data.Seeds;

public static class ProyectoSeed
{
    public const int Activos = 10;
    public const int Cerrados = 5;

    private static readonly EstadoProyecto[] EstadosActivos =
        [EstadoProyecto.EnProgreso, EstadoProyecto.Planificado, EstadoProyecto.Pausado];

    public static List<Proyecto> Datos()
    {
        var lista = new List<Proyecto>();

        for (var i = 0; i < Activos; i++)
            lista.Add(ProyectoFactory.Crear(id: i + 1, indice: i, jefeId: i + 1, EstadosActivos[i % EstadosActivos.Length]));

        for (var i = 0; i < Cerrados; i++)
        {
            var estado = i % 2 == 0 ? EstadoProyecto.Finalizado : EstadoProyecto.Cancelado;
            lista.Add(ProyectoFactory.Crear(id: Activos + i + 1, indice: Activos + i, jefeId: i + 1, estado));
        }

        return lista;
    }

    public static void Aplicar(ModelBuilder modelBuilder) =>
        modelBuilder.Entity<Proyecto>().HasData(Datos());
}
