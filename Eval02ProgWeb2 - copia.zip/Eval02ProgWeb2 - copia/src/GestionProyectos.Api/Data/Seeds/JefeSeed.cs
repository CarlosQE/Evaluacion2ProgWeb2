using GestionProyectos.Api.Data.Factories;
using GestionProyectos.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GestionProyectos.Api.Data.Seeds;

public static class JefeSeed
{
    public const int Cantidad = 12;

    public static List<Jefe> Datos() => JefeFactory.CrearVarios(Cantidad);

    public static void Aplicar(ModelBuilder modelBuilder) =>
        modelBuilder.Entity<Jefe>().HasData(Datos());
}
