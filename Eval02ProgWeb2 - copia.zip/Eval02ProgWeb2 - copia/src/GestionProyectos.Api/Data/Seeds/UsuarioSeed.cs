using GestionProyectos.Api.Data.Factories;
using GestionProyectos.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GestionProyectos.Api.Data.Seeds;

public static class UsuarioSeed
{
    public const string ContrasenaAdmin = "Admin2026";
    public const string ContrasenaGestor = "Gestor2026";
    public const int Gestores = 10;

    public static List<Usuario> Datos()
    {
        var lista = new List<Usuario> { UsuarioFactory.CrearAdministrador(1, ContrasenaAdmin) };
        for (var i = 0; i < Gestores; i++)
            lista.Add(UsuarioFactory.CrearGestor(id: i + 2, indice: i, ContrasenaGestor));
        return lista;
    }

    public static void Aplicar(ModelBuilder modelBuilder) =>
        modelBuilder.Entity<Usuario>().HasData(Datos());
}
