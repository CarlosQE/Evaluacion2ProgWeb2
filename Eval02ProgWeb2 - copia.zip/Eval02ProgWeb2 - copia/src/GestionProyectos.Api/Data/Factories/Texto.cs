using System.Globalization;
using System.Text;

namespace GestionProyectos.Api.Data.Factories;

internal static class Texto
{
    public static string Slug(string valor)
    {
        var sb = new StringBuilder();
        foreach (var c in valor.Normalize(NormalizationForm.FormD))
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark || char.IsWhiteSpace(c)) continue;
            sb.Append(char.ToLowerInvariant(c));
        }
        return sb.ToString().Normalize(NormalizationForm.FormC);
    }
}
