using GestionProyectos.Api.Models;
using GestionProyectos.Api.Seguridad;

namespace GestionProyectos.Api.Data.Factories;

public static class UsuarioFactory
{
    private static readonly string[] Nombres =
    [
        "Administrador General", "Carla Fernández", "Jorge Mamani", "Sofía Ríos", "Diego Paredes",
        "Elena Castro", "Hugo Medina", "Inés Delgado", "Óscar Rivera", "Patricia Molina",
        "Raúl Herrera", "Silvia Navarro",
    ];

    public static Usuario Crear(int id, string nombreUsuario, string nombreCompleto, string contrasena, string rol) => new()
    {
        Id = id,
        NombreUsuario = nombreUsuario,
        NombreCompleto = nombreCompleto,
        Rol = rol,
        PasswordHash = PasswordHasher.HashearDeterminista(contrasena, $"semilla:{nombreUsuario}"),
    };

    public static Usuario CrearGestor(int id, int indice, string contrasena) =>
        Crear(id, $"gestor{indice + 1:00}", Nombres[1 + indice % (Nombres.Length - 1)], contrasena, Roles.Gestor);

    public static Usuario CrearAdministrador(int id, string contrasena) =>
        Crear(id, "admin", Nombres[0], contrasena, Roles.Administrador);
}
