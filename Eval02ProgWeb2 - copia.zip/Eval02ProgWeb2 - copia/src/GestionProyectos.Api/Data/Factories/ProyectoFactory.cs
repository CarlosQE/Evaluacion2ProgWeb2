using GestionProyectos.Api.Models;
using GestionProyectos.Contratos.DTOs;

namespace GestionProyectos.Api.Data.Factories;

public static class ProyectoFactory
{
    private static readonly string[] Tipos =
    [
        "Portal Web", "App Móvil", "Sistema", "Plataforma", "Migración a la Nube",
        "Dashboard", "API", "Automatización", "Módulo", "Rediseño",
    ];

    private static readonly string[] Areas =
    [
        "Ventas", "Recursos Humanos", "Logística", "Finanzas", "Inventario",
        "Atención al Cliente", "Marketing", "Compras", "Producción", "Calidad",
    ];

    private static readonly string[] Objetivos =
    [
        "centralizar la información y reducir tiempos de respuesta",
        "automatizar tareas manuales repetitivas",
        "mejorar la trazabilidad de cada operación",
        "ofrecer reportes en tiempo real a la gerencia",
        "reducir costos operativos del área",
    ];

    public const int MaximoUnicos = 100;

    public static Proyecto Crear(int id, int indice, int jefeId, EstadoProyecto estado)
    {
        if (indice is < 0 or >= MaximoUnicos)
            throw new ArgumentOutOfRangeException(nameof(indice), $"La fábrica genera hasta {MaximoUnicos} proyectos únicos.");

        var tipo = Tipos[indice % Tipos.Length];
        var area = Areas[(indice + indice / Tipos.Length) % Areas.Length];

        return new Proyecto
        {
            Id = id,
            Nombre = $"{tipo} de {area}",
            Descripcion = $"{tipo} para el área de {area} que busca {Objetivos[indice % Objetivos.Length]}.",
            Estado = estado,
            JefeId = jefeId,
        };
    }
}
