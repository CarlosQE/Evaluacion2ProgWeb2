using GestionProyectos.Api.Models;

namespace GestionProyectos.Api.Data.Factories;

public static class JefeFactory
{
    private static readonly string[] Nombres =
    [
        "Andrés", "Lucía", "Fernando", "Valeria", "Rodrigo", "Camila", "Mauricio", "Daniela", "Gonzalo", "Paola",
        "Sergio", "Mariana", "Ricardo", "Natalia", "Eduardo", "Carolina", "Alejandro", "Gabriela", "Marcelo", "Verónica",
    ];

    private static readonly string[] Apellidos =
    [
        "Gutiérrez", "Rojas", "Mendoza", "Vargas", "Salazar", "Quiroga", "Céspedes", "Montaño", "Antezana", "Villarroel",
        "Saavedra", "Zambrana", "Peñaranda", "Camacho", "Lozada", "Arce", "Pinto", "Suárez", "Torrez", "Aguilar",
    ];

    private static readonly string[] Cargos =
    [
        "Gerente de Proyectos", "Líder Técnico", "Jefe de Desarrollo", "Arquitecto de Software", "Scrum Master",
        "Jefe de Operaciones", "Coordinador de TI", "Jefe de Infraestructura", "Product Owner", "Director de Tecnología",
    ];

    public const int MaximoUnicos = 400;
    public const string Dominio = "gestionproyectos.com";

    public static Jefe Crear(int id, int indice)
    {
        if (indice is < 0 or >= MaximoUnicos)
            throw new ArgumentOutOfRangeException(nameof(indice), $"La fábrica genera hasta {MaximoUnicos} jefes únicos.");

        var nombre = Nombres[indice % Nombres.Length];
        var apellido = Apellidos[(indice + indice / Nombres.Length) % Apellidos.Length];

        return new Jefe
        {
            Id = id,
            Nombre = $"{nombre} {apellido}",
            Cargo = Cargos[indice % Cargos.Length],
            Correo = $"{Texto.Slug(nombre)}.{Texto.Slug(apellido)}@{Dominio}",
        };
    }

    public static List<Jefe> CrearVarios(int cantidad, int idInicial = 1) =>
        Enumerable.Range(0, cantidad).Select(i => Crear(idInicial + i, i)).ToList();
}
