using System.Text;
using System.Text.Json.Serialization;
using GestionProyectos.Api.Data;
using GestionProyectos.Api.Interfaces;
using GestionProyectos.Api.Seguridad;
using GestionProyectos.Api.Services;
using GestionProyectos.Api.Validaciones;
using GestionProyectos.Contratos.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<GestionProyectosDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("GestionProyectos")
        ?? throw new InvalidOperationException("Falta la cadena de conexión 'GestionProyectos'.")));

var jwt = builder.Configuration.GetSection(JwtOpciones.Seccion).Get<JwtOpciones>()
    ?? throw new InvalidOperationException("Falta la sección 'Jwt' en appsettings.");
if (Encoding.UTF8.GetByteCount(jwt.Clave) < 32)
    throw new InvalidOperationException("La clave 'Jwt:Clave' debe tener al menos 32 caracteres.");

builder.Services.Configure<JwtOpciones>(builder.Configuration.GetSection(JwtOpciones.Seccion));
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.MapInboundClaims = false;
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt.Emisor,
            ValidateAudience = true,
            ValidAudience = jwt.Audiencia,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Clave)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1),
            RoleClaimType = System.Security.Claims.ClaimTypes.Role,
            NameClaimType = "unique_name",
        };

        o.Events = new JwtBearerEvents
        {
            OnChallenge = async contexto =>
            {
                contexto.HandleResponse();
                var detalle = contexto.AuthenticateFailure switch
                {
                    SecurityTokenExpiredException => "El token expiró. Inicie sesión de nuevo en POST /api/auth/login.",
                    not null => "El token no es válido. Inicie sesión de nuevo en POST /api/auth/login.",
                    null => "Falta el token. Inicie sesión en POST /api/auth/login y use el botón 'Authorize' de Swagger.",
                };
                contexto.Response.StatusCode = StatusCodes.Status401Unauthorized;
                contexto.Response.Headers.WWWAuthenticate = "Bearer";
                await contexto.Response.WriteAsJsonAsync(
                    new { title = "No autorizado", status = 401, detail = detalle },
                    contexto.HttpContext.RequestAborted);
            },
        };
    });
builder.Services.AddAuthorization();

builder.Services.AddSingleton<IPasswordHasher, PasswordHasher>();
builder.Services.AddSingleton<ITokenService, TokenService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IJefeService, JefeService>();
builder.Services.AddScoped<IProyectoService, ProyectoService>();

builder.Services.AddControllers()
    .AddJsonOptions(o =>
        o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter(allowIntegerValues: false)))
    .ConfigureApiBehaviorOptions(o => o.InvalidModelStateResponseFactory = RespuestaValidacion.Crear);
builder.Services.ConfigureHttpJsonOptions(o =>
    o.SerializerOptions.Converters.Add(new JsonStringEnumConverter(allowIntegerValues: false)));
builder.Services.AddProblemDetails();
builder.Services.AddOpenApi(o =>
{
    o.AddDocumentTransformer<BearerOpenApiTransformer>();
    o.AddSchemaTransformer<EjemplosOpenApiTransformer>();
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    scope.ServiceProvider.GetRequiredService<GestionProyectosDbContext>().Database.Migrate();
}

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwaggerUI(o =>
    {
        o.SwaggerEndpoint("/openapi/v1.json", "Gestión de Proyectos v1");
        o.DocumentTitle = "Gestión de Proyectos - API";
        o.EnablePersistAuthorization();
    });
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
