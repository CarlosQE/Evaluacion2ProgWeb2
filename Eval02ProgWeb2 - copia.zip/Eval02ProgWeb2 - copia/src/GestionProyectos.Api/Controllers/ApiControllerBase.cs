using GestionProyectos.Contratos.Comun;
using Microsoft.AspNetCore.Mvc;

namespace GestionProyectos.Api.Controllers;

[ApiController]
[Produces("application/json")]
public abstract class ApiControllerBase : ControllerBase
{
    protected ActionResult Fallo(TipoError error, string? mensaje) =>
        Problem(detail: mensaje, statusCode: error switch
        {
            TipoError.NoEncontrado => StatusCodes.Status404NotFound,
            TipoError.Conflicto => StatusCodes.Status409Conflict,
            TipoError.NoAutorizado => StatusCodes.Status401Unauthorized,
            _ => StatusCodes.Status400BadRequest,
        });
}
