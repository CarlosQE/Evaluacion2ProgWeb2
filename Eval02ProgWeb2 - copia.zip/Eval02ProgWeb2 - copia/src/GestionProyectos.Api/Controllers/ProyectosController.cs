using GestionProyectos.Contratos.Comun;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GestionProyectos.Api.Controllers;

[Route("api/[controller]")]
[Authorize]
[ProducesResponseType<ProblemDetails>(StatusCodes.Status401Unauthorized)]
[ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
public class ProyectosController(IProyectoService proyectos) : ApiControllerBase
{
    [HttpGet]
    public Task<List<ProyectoRespuestaDto>> Listar([FromQuery] string? texto, [FromQuery] EstadoProyecto? estado) =>
        proyectos.ListarAsync(texto, estado);

    [HttpGet("{id:int}")]
    [ProducesResponseType<ProyectoRespuestaDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ProyectoRespuestaDto>> Obtener(int id)
    {
        var proyecto = await proyectos.ObtenerAsync(id);
        return proyecto is null ? Fallo(TipoError.NoEncontrado, $"No existe el proyecto con Id {id}.") : proyecto;
    }

    [HttpPost]
    [ProducesResponseType<ProyectoRespuestaDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ProyectoRespuestaDto>> Crear(ProyectoCrearDto dto)
    {
        var resultado = await proyectos.CrearAsync(dto);
        return resultado.Error is { } error
            ? Fallo(error, resultado.Mensaje)
            : CreatedAtAction(nameof(Obtener), new { id = resultado.Valor!.Id }, resultado.Valor);
    }

    [HttpPatch("{id:int}/estado")]
    [ProducesResponseType<ProyectoRespuestaDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ProyectoRespuestaDto>> CambiarEstado(int id, ProyectoCambiarEstadoDto dto)
    {
        var resultado = await proyectos.CambiarEstadoAsync(id, dto.Estado);
        return resultado.Error is { } error ? Fallo(error, resultado.Mensaje) : Ok(resultado.Valor);
    }
}
