using System.Security.Claims;
using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.JsonWebTokens;

namespace GestionProyectos.Api.Controllers;

[Route("api/[controller]")]
public class AuthController(IAuthService auth) : ApiControllerBase
{
    [HttpPost("login")]
    [AllowAnonymous]
    [ProducesResponseType<TokenDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<TokenDto>> Login(LoginDto login)
    {
        var resultado = await auth.IniciarSesionAsync(login);
        return resultado.Error is { } error ? Fallo(error, resultado.Mensaje) : Ok(resultado.Valor);
    }

    [HttpGet("yo")]
    [Authorize]
    [ProducesResponseType<UsuarioDto>(StatusCodes.Status200OK)]
    public ActionResult<UsuarioDto> Yo() => new UsuarioDto(
        int.Parse(User.FindFirstValue(JwtRegisteredClaimNames.Sub) ?? "0"),
        User.FindFirstValue(JwtRegisteredClaimNames.UniqueName) ?? "",
        User.FindFirstValue(JwtRegisteredClaimNames.Name) ?? "",
        User.FindFirstValue(ClaimTypes.Role) ?? "");
}
