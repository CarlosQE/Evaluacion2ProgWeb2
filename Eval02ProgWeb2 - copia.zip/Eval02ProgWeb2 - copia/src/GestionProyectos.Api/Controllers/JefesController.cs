using GestionProyectos.Contratos.DTOs;
using GestionProyectos.Contratos.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GestionProyectos.Api.Controllers;

[Route("api/[controller]")]
[Authorize]
[ProducesResponseType<ProblemDetails>(StatusCodes.Status401Unauthorized)]
[ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
public class JefesController(IJefeService jefes) : ApiControllerBase
{
    [HttpGet]
    public Task<List<JefeRespuestaDto>> Listar([FromQuery] string? texto) => jefes.ListarAsync(texto);

    [HttpGet("{id:int}")]
    [ProducesResponseType<JefeRespuestaDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<JefeRespuestaDto>> Obtener(int id)
    {
        var jefe = await jefes.ObtenerAsync(id);
        return jefe is null ? Fallo(Contratos.Comun.TipoError.NoEncontrado, $"No existe el jefe con Id {id}.") : jefe;
    }

    [HttpPost]
    [ProducesResponseType<JefeRespuestaDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<JefeRespuestaDto>> Crear(JefeCrearDto dto)
    {
        var resultado = await jefes.CrearAsync(dto);
        return resultado.Error is { } error
            ? Fallo(error, resultado.Mensaje)
            : CreatedAtAction(nameof(Obtener), new { id = resultado.Valor!.Id }, resultado.Valor);
    }
}
