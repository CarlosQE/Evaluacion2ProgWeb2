namespace GestionProyectos.Api.Models;

public class Usuario
{
    public int Id { get; set; }
    public required string NombreUsuario { get; set; }
    public required string NombreCompleto { get; set; }
    public required string PasswordHash { get; set; }
    public required string Rol { get; set; }
}
