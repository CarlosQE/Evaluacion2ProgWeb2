namespace GestionProyectos.Api.Models;

public class Jefe
{
    public int Id { get; set; }
    public required string Nombre { get; set; }
    public required string Cargo { get; set; }
    public required string Correo { get; set; }

    public List<Proyecto> Proyectos { get; set; } = [];
}
