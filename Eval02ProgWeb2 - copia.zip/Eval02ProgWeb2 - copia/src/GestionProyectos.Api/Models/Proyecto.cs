using GestionProyectos.Contratos.DTOs;

namespace GestionProyectos.Api.Models;

public class Proyecto
{
    public int Id { get; set; }
    public required string Nombre { get; set; }
    public required string Descripcion { get; set; }
    public EstadoProyecto Estado { get; set; } = EstadoProyecto.Planificado;

    public int JefeId { get; set; }
    public Jefe Jefe { get; set; } = null!;
}
