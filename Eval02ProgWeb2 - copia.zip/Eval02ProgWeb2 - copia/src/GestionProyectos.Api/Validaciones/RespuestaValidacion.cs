using GestionProyectos.Contratos.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace GestionProyectos.Api.Validaciones;

public static class RespuestaValidacion
{
    public static IActionResult Crear(ActionContext contexto)
    {
        var estado = contexto.ModelState;
        var errores = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);

        var hayErrorJson = estado.Keys.Any(k => k.StartsWith('$'));

        foreach (var (clave, entrada) in estado)
        {
            if (entrada.Errors.Count == 0) continue;

            if (clave.StartsWith('$'))
            {
                var campo = clave.TrimStart('$', '.');
                errores[campo.Length == 0 ? "cuerpo" : campo] = [MensajeJson(campo)];
            }
            else if (clave.Length == 0)
            {
                errores["cuerpo"] = ["Debe enviar los datos en el cuerpo de la solicitud (JSON)."];
            }
            else if (!hayErrorJson)
            {
                errores[clave] = entrada.Errors.Select(e => Traducir(clave, e.ErrorMessage)).ToArray();
            }
        }

        var problema = new ValidationProblemDetails(errores)
        {
            Title = "Los datos enviados no son válidos.",
            Status = StatusCodes.Status400BadRequest,
            Type = "https://tools.ietf.org/html/rfc9110#section-15.5.1",
        };
        return new BadRequestObjectResult(problema) { ContentTypes = { "application/problem+json" } };
    }

    private static string MensajeJson(string campo) =>
        campo.Length == 0
            ? "El cuerpo de la solicitud no es un JSON válido."
            : campo.Equals("estado", StringComparison.OrdinalIgnoreCase)
                ? $"Estado no válido. Debe ir entre comillas, por ejemplo \"estado\": \"Planificado\". " +
                  $"Valores permitidos: {string.Join(", ", Enum.GetNames<EstadoProyecto>())}."
                : $"El valor de '{campo}' no tiene el formato correcto. Los textos van entre comillas (\"...\") y los números sin comillas.";

    private static string Traducir(string clave, string mensaje)
    {
        if (string.IsNullOrEmpty(mensaje) || mensaje.StartsWith("The value '") || mensaje.StartsWith("The value is invalid"))
            return clave.Equals("estado", StringComparison.OrdinalIgnoreCase)
                ? $"Estado no válido. Valores permitidos: {string.Join(", ", Enum.GetNames<EstadoProyecto>())}."
                : $"El valor indicado para '{clave}' no es válido.";
        if (mensaje.StartsWith("A non-empty request body is required"))
            return "Debe enviar los datos en el cuerpo de la solicitud (JSON).";
        return mensaje;
    }
}
